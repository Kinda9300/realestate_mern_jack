import React from 'react';
const Collapsible =()=>{
    return(
        <div><h1>collapse</h1></div>
    )
}
export default Collapsible;